package com.example.two.model;

import java.util.List;

public class reView {
    private String result;

    private List<ContentReview> contentReviewList;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public List<ContentReview> getContentReviewList() {
        return contentReviewList;
    }

    public void setContentReviewList(List<ContentReview> contentReviewList) {
        this.contentReviewList = contentReviewList;
    }
}
