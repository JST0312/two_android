package com.example.two.model;

import java.util.List;

public class MovieRankList {

    private List<MovieRank> rank;

    public List<MovieRank> getRank() {
        return rank;
    }

    public void setRank(List<MovieRank> rank) {
        this.rank = rank;
    }
}
