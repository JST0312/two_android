package com.example.two.model;

import java.util.List;

public class ChoiceList {

  private List<Choice> contentLike_list;

    public List<Choice> getContentLike_list() {
        return contentLike_list;
    }

    public void setContentLike_list(List<Choice> contentLike_list) {
        this.contentLike_list = contentLike_list;
    }
}
