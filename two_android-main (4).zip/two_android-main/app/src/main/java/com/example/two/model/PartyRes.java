package com.example.two.model;

public class PartyRes {
    String result;
    Chat party;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Chat getParty() {
        return party;
    }

    public void setParty(Chat party) {
        this.party = party;
    }
}
