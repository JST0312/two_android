package com.example.two.model;

import java.util.List;

public class ContentWatchList {

    private List<ContentWatch> contentWatch_list;

    public List<ContentWatch> getContentWatch_list() {
        return contentWatch_list;
    }

    public void setContentWatch_list(List<ContentWatch> contentWatch_list) {
        this.contentWatch_list = contentWatch_list;
    }
}
