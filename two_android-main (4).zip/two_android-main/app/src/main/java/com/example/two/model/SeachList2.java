package com.example.two.model;

import java.util.List;

public class SeachList2 {

    private List<Seach> tv;

    public List<Seach> getTv() {
        return tv;
    }

    public void setTv(List<Seach> tv) {
        this.tv = tv;
    }
}
