package com.example.two.model;

import java.util.List;

public class UserList {


        private List<User> user;

        public List<User> getUser() {
            return user;
        }

        public void setUser(List<User> user) {
            this.user = user;
        }

}
