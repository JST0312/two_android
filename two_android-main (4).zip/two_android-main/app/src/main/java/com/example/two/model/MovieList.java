package com.example.two.model;

import java.util.List;

public class MovieList {

    private List<Movie> recommendList;


    public List<Movie> getRecommendList() {
        return recommendList;
    }

    public void setRecommendList(List<Movie> recommendList) {
        this.recommendList = recommendList;
    }
}
