package com.example.two.model;

import java.util.List;
import java.util.PrimitiveIterator;

public class SeachList {

    private List<Seach> movie;

    public List<Seach> getMovie() {
        return movie;
    }

    public void setMovie(List<Seach> movie) {
        this.movie = movie;
    }
}
