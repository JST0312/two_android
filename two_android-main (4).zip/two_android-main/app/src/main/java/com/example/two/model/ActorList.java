package com.example.two.model;

import java.util.List;

public class ActorList {

    private List<Actor> cast;

    public List<Actor> getCast() {
        return cast;
    }

    public void setCast(List<Actor> cast) {
        this.cast = cast;
    }
}
