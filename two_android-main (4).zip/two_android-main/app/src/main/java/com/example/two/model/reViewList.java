package com.example.two.model;

import java.util.List;

public class reViewList {
    private List<reView> contentReviewList;

    public List<reView> getContentReviewList() {
        return contentReviewList;
    }

    public void setContentReviewList(List<reView> contentReviewList) {
        this.contentReviewList = contentReviewList;
    }
}
